package com.willflood.rayneovrcontroller;

public final class NativeInputBridge {
    static { System.loadLibrary("uinputjni"); }
    private NativeInputBridge() {}

    public static native String listControllers();
    public static native int openDevice(String path, boolean grab);
    public static native int[] readEvent(int fd, int timeoutMs);
    public static native int[] getAbsInfo(int fd, int code);
    public static native String getDeviceName(int fd);
    public static native void closeDevice(int fd);
}
