package com.willflood.rayneovrcontroller;

public final class PhysicalBridgeManager {
    private PhysicalBridgeManager() {}
    public static volatile IInputBridge bridge;
    public static volatile boolean grabbed = false;
    public static volatile boolean passthrough = false;
    public static volatile boolean headMix = false;
    public static volatile int profile = 0; // 0 auto, 1 xbox/linux raw, 2 android raw
    public static volatile String devicePath = "";
    public static volatile String deviceName = "";

    public static void clearGrabState() {
        grabbed = false;
        passthrough = false;
        headMix = false;
        devicePath = "";
        deviceName = "";
    }
}
