#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <linux/uinput.h>
#include <linux/input.h>

static int emit_ev(int fd, unsigned short type, unsigned short code, int value) {
    struct input_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = type;
    ev.code = code;
    ev.value = value;
    return write(fd, &ev, sizeof(ev)) == (ssize_t)sizeof(ev) ? 0 : -errno;
}

static int setup_abs(int fd, int code, int min, int max, int flat, int fuzz) {
    if (ioctl(fd, UI_SET_ABSBIT, code) < 0) return -errno;
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_willflood_rayneovrcontroller_NativeUInput_openGamepad(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (fd < 0) return -errno;

    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0) {
        int e = errno; close(fd); return -1000-e;
    }

    int buttons[] = {
        BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST,
        BTN_TL, BTN_TR, BTN_TL2, BTN_TR2,
        BTN_SELECT, BTN_START, BTN_MODE,
        BTN_THUMBL, BTN_THUMBR,
        BTN_DPAD_UP, BTN_DPAD_DOWN, BTN_DPAD_LEFT, BTN_DPAD_RIGHT
    };
    for (unsigned i=0; i<sizeof(buttons)/sizeof(buttons[0]); i++) {
        if (ioctl(fd, UI_SET_KEYBIT, buttons[i]) < 0) {
            int e=errno; close(fd); return -1100-e;
        }
    }

    int axes[] = { ABS_X, ABS_Y, ABS_Z, ABS_RZ, ABS_RX, ABS_RY, ABS_GAS, ABS_BRAKE, ABS_HAT0X, ABS_HAT0Y };
    for (unsigned i=0; i<sizeof(axes)/sizeof(axes[0]); i++) {
        if (setup_abs(fd, axes[i], 0, 0, 0, 0) < 0) {
            int e=errno; close(fd); return -1200-e;
        }
    }

    struct uinput_user_dev uidev;
    memset(&uidev, 0, sizeof(uidev));
    snprintf(uidev.name, UINPUT_MAX_NAME_SIZE, "RayNeo VR Gamepad");
    uidev.id.bustype = BUS_USB;
    uidev.id.vendor  = 0x1BBB;
    uidev.id.product = 0xAF52;
    uidev.id.version = 1;

    uidev.absmin[ABS_X] = -32767;  uidev.absmax[ABS_X] = 32767; uidev.absflat[ABS_X] = 1024; uidev.absfuzz[ABS_X] = 16;
    uidev.absmin[ABS_Y] = -32767;  uidev.absmax[ABS_Y] = 32767; uidev.absflat[ABS_Y] = 1024; uidev.absfuzz[ABS_Y] = 16;
    uidev.absmin[ABS_RX] = -32767; uidev.absmax[ABS_RX] = 32767; uidev.absflat[ABS_RX] = 1024; uidev.absfuzz[ABS_RX] = 16;
    uidev.absmin[ABS_RY] = -32767; uidev.absmax[ABS_RY] = 32767; uidev.absflat[ABS_RY] = 1024; uidev.absfuzz[ABS_RY] = 16;
    // Keep both common right-stick conventions available.
    uidev.absmin[ABS_Z] = -32767;  uidev.absmax[ABS_Z] = 32767; uidev.absflat[ABS_Z] = 1024; uidev.absfuzz[ABS_Z] = 16;
    uidev.absmin[ABS_RZ] = -32767; uidev.absmax[ABS_RZ] = 32767; uidev.absflat[ABS_RZ] = 1024; uidev.absfuzz[ABS_RZ] = 16;
    uidev.absmin[ABS_GAS] = 0;     uidev.absmax[ABS_GAS] = 255;
    uidev.absmin[ABS_BRAKE] = 0;   uidev.absmax[ABS_BRAKE] = 255;
    uidev.absmin[ABS_HAT0X] = -1;  uidev.absmax[ABS_HAT0X] = 1;
    uidev.absmin[ABS_HAT0Y] = -1;  uidev.absmax[ABS_HAT0Y] = 1;

    if (write(fd, &uidev, sizeof(uidev)) != (ssize_t)sizeof(uidev)) {
        int e=errno; close(fd); return -2000-e;
    }
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
        int e=errno; close(fd); return -3000-e;
    }

    // Give Android InputReader a moment to enumerate the new device.
    usleep(300000);
    return fd;
}

JNIEXPORT jint JNICALL
Java_com_willflood_rayneovrcontroller_NativeUInput_setGamepadState(
        JNIEnv *env, jclass cls, jint fd,
        jint lx, jint ly, jint rx, jint ry,
        jint lt, jint rt, jint hatX, jint hatY, jint axisMode) {
    (void)env; (void)cls;
    if (fd < 0) return -1;
    emit_ev(fd, EV_ABS, ABS_X, lx);
    emit_ev(fd, EV_ABS, ABS_Y, ly);
    if (axisMode == 1) {
        // Linux/xpad style: right stick RX/RY. Keep Z/RZ neutral.
        emit_ev(fd, EV_ABS, ABS_RX, rx);
        emit_ev(fd, EV_ABS, ABS_RY, ry);
        emit_ev(fd, EV_ABS, ABS_Z, 0);
        emit_ev(fd, EV_ABS, ABS_RZ, 0);
    } else {
        // Android common convention: right stick Z/RZ. Keep RX/RY neutral.
        emit_ev(fd, EV_ABS, ABS_Z, rx);
        emit_ev(fd, EV_ABS, ABS_RZ, ry);
        emit_ev(fd, EV_ABS, ABS_RX, 0);
        emit_ev(fd, EV_ABS, ABS_RY, 0);
    }
    emit_ev(fd, EV_ABS, ABS_GAS, lt);
    emit_ev(fd, EV_ABS, ABS_BRAKE, rt);
    emit_ev(fd, EV_ABS, ABS_HAT0X, hatX);
    emit_ev(fd, EV_ABS, ABS_HAT0Y, hatY);
    emit_ev(fd, EV_SYN, SYN_REPORT, 0);
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_willflood_rayneovrcontroller_NativeUInput_gamepadButton(
        JNIEnv *env, jclass cls, jint fd, jint code, jboolean pressed) {
    (void)env; (void)cls;
    if (fd < 0) return -1;
    emit_ev(fd, EV_KEY, (unsigned short)code, pressed ? 1 : 0);
    emit_ev(fd, EV_SYN, SYN_REPORT, 0);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_willflood_rayneovrcontroller_NativeUInput_closeGamepad(JNIEnv *env, jclass cls, jint fd) {
    (void)env; (void)cls;
    if (fd >= 0) {
        // Return sticks/triggers/hat to neutral before destroying the device.
        emit_ev(fd, EV_ABS, ABS_X, 0); emit_ev(fd, EV_ABS, ABS_Y, 0);
        emit_ev(fd, EV_ABS, ABS_RX, 0); emit_ev(fd, EV_ABS, ABS_RY, 0);
        emit_ev(fd, EV_ABS, ABS_Z, 0); emit_ev(fd, EV_ABS, ABS_RZ, 0);
        emit_ev(fd, EV_ABS, ABS_GAS, 0); emit_ev(fd, EV_ABS, ABS_BRAKE, 0);
        emit_ev(fd, EV_ABS, ABS_HAT0X, 0); emit_ev(fd, EV_ABS, ABS_HAT0Y, 0);
        emit_ev(fd, EV_SYN, SYN_REPORT, 0);
        ioctl(fd, UI_DEV_DESTROY);
        close(fd);
    }
}

// -----------------------------------------------------------------------------
// v0.2 physical-controller evdev bridge (used inside Shizuku UserService)
// -----------------------------------------------------------------------------
#include <dirent.h>
#include <poll.h>
#include <stdlib.h>

#define BITS_PER_LONG (sizeof(unsigned long) * 8)
#define NBITS(x) ((((x)-1) / BITS_PER_LONG) + 1)
#define TEST_BIT(bit, array) (((array)[(bit) / BITS_PER_LONG] >> ((bit) % BITS_PER_LONG)) & 1UL)

static jstring jstr(JNIEnv *env, const char *s) {
    return (*env)->NewStringUTF(env, s ? s : "");
}

static int looks_like_gamepad(int fd) {
    unsigned long key_bits[NBITS(KEY_MAX + 1)];
    unsigned long abs_bits[NBITS(ABS_MAX + 1)];
    memset(key_bits, 0, sizeof(key_bits));
    memset(abs_bits, 0, sizeof(abs_bits));
    if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(key_bits)), key_bits) < 0) return 0;
    if (ioctl(fd, EVIOCGBIT(EV_ABS, sizeof(abs_bits)), abs_bits) < 0) return 0;
    int has_face = TEST_BIT(BTN_SOUTH, key_bits) || TEST_BIT(BTN_EAST, key_bits) ||
                   TEST_BIT(BTN_NORTH, key_bits) || TEST_BIT(BTN_WEST, key_bits);
    int has_xy = TEST_BIT(ABS_X, abs_bits) && TEST_BIT(ABS_Y, abs_bits);
    return has_face && has_xy;
}

JNIEXPORT jstring JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_listControllers(JNIEnv *env, jclass cls) {
    (void)cls;
    DIR *dir = opendir("/dev/input");
    if (!dir) {
        char out[128]; snprintf(out, sizeof(out), "ERROR|opendir /dev/input|%d", errno);
        return jstr(env, out);
    }
    char *buf = calloc(1, 8192);
    if (!buf) { closedir(dir); return jstr(env, "ERROR|oom|12"); }
    size_t used = 0;
    struct dirent *de;
    while ((de = readdir(dir)) != NULL) {
        if (strncmp(de->d_name, "event", 5) != 0) continue;
        char path[128]; snprintf(path, sizeof(path), "/dev/input/%s", de->d_name);
        int fd = open(path, O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;
        char name[256]; memset(name, 0, sizeof(name));
        if (ioctl(fd, EVIOCGNAME(sizeof(name)-1), name) < 0) snprintf(name, sizeof(name), "unknown");
        int gamepad = looks_like_gamepad(fd);
        close(fd);
        if (!gamepad) continue;
        if (strstr(name, "RayNeo VR Gamepad") != NULL) continue;
        char line[512]; snprintf(line, sizeof(line), "%s|%s\n", path, name);
        size_t n = strlen(line);
        if (used + n + 1 < 8192) { memcpy(buf + used, line, n); used += n; buf[used] = 0; }
    }
    closedir(dir);
    if (used == 0) snprintf(buf, 8192, "NONE|No physical gamepad-shaped evdev device found\n");
    jstring result = jstr(env, buf);
    free(buf);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_openDevice(JNIEnv *env, jclass cls, jstring jpath, jboolean grab) {
    (void)cls;
    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return -EINVAL;
    int fd = open(path, O_RDONLY | O_NONBLOCK);
    int e = errno;
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    if (fd < 0) return -e;
    if (grab) {
        int one = 1;
        if (ioctl(fd, EVIOCGRAB, one) < 0) { e = errno; close(fd); return -e; }
    }
    return fd;
}

JNIEXPORT jintArray JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_readEvent(JNIEnv *env, jclass cls, jint fd, jint timeoutMs) {
    (void)cls;
    jint vals[4] = {0,0,0,0};
    if (fd < 0) { vals[0] = -ENODEV; }
    else {
        struct pollfd pfd; pfd.fd = fd; pfd.events = POLLIN; pfd.revents = 0;
        int pr = poll(&pfd, 1, timeoutMs < 0 ? 0 : timeoutMs);
        if (pr == 0) vals[0] = 1; // timeout/no event
        else if (pr < 0) vals[0] = -errno;
        else {
            struct input_event ev;
            ssize_t n = read(fd, &ev, sizeof(ev));
            if (n == (ssize_t)sizeof(ev)) {
                vals[0] = 0; vals[1] = ev.type; vals[2] = ev.code; vals[3] = ev.value;
            } else if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) vals[0] = 1;
            else vals[0] = n < 0 ? -errno : -EIO;
        }
    }
    jintArray arr = (*env)->NewIntArray(env, 4);
    (*env)->SetIntArrayRegion(env, arr, 0, 4, vals);
    return arr;
}

JNIEXPORT jintArray JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_getAbsInfo(JNIEnv *env, jclass cls, jint fd, jint code) {
    (void)cls;
    jint vals[6] = {0,0,0,0,0,0};
    if (fd < 0) vals[0] = -ENODEV;
    else {
        struct input_absinfo ai; memset(&ai, 0, sizeof(ai));
        if (ioctl(fd, EVIOCGABS(code), &ai) < 0) vals[0] = -errno;
        else { vals[0]=0; vals[1]=ai.value; vals[2]=ai.minimum; vals[3]=ai.maximum; vals[4]=ai.fuzz; vals[5]=ai.flat; }
    }
    jintArray arr = (*env)->NewIntArray(env, 6);
    (*env)->SetIntArrayRegion(env, arr, 0, 6, vals);
    return arr;
}

JNIEXPORT jstring JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_getDeviceName(JNIEnv *env, jclass cls, jint fd) {
    (void)cls;
    char name[256]; memset(name, 0, sizeof(name));
    if (fd < 0 || ioctl(fd, EVIOCGNAME(sizeof(name)-1), name) < 0) snprintf(name, sizeof(name), "unknown");
    return jstr(env, name);
}

JNIEXPORT void JNICALL
Java_com_willflood_rayneovrcontroller_NativeInputBridge_closeDevice(JNIEnv *env, jclass cls, jint fd) {
    (void)env; (void)cls;
    if (fd >= 0) { int zero = 0; ioctl(fd, EVIOCGRAB, zero); close(fd); }
}
