package com.willflood.rayneovrcontroller;

interface IInputBridge {
    String listControllers();
    int openDevice(String path, boolean grab);
    int[] readEvent(int timeoutMs);
    int[] getAbsInfo(int code);
    String currentDeviceName();
    int currentFd();
    int serviceUid();
    void releaseDevice();
    void destroy();
}
