# RayNeo VR Controller v0.2 — COMBINED CONTROLLER LAB

Experimental Android app for RayNeo Air 4 Pro.

## Goal

Make games that refuse to combine two controllers behave like games that do.

Instead of exposing:

- physical controller as controller 1
- RayNeo head tracker as controller 2

v0.2 can experimentally do:

**physical controller + RayNeo head aim -> ONE RayNeo virtual controller -> game**

This is specifically aimed at the Minecraft-style problem where head-look works OR the physical right stick works, but not both together.

## What is already preserved from v0.1

- direct Air 4 Pro IMU input
- virtual `/dev/uinput` Android gamepad
- gyro-rate head aim
- angle head aim mode
- sensitivity / deadzone / smoothing
- recenter / recalibrate
- Z/RZ and RX/RY virtual right-stick compatibility

## New v0.2 LAB controls

1. `CONNECT SHIZUKU`
2. `FIND CONTROLLERS`
3. select the real physical controller
4. `GRAB CONTROLLER`
5. enable `PASSTHROUGH`
6. verify physical buttons/sticks still work through the RayNeo virtual pad
7. enable `HEAD MIX`

When HEAD MIX is on:

`final right stick = physical right stick + RayNeo head right stick`

The result is clamped to the normal analogue range.

## Safety / panic release

`PANIC RELEASE` immediately closes the evdev file descriptor and releases `EVIOCGRAB`, returning the physical controller to Android.

If the privileged bridge process dies, Linux also releases the grab when the file descriptor closes.

## Important

This is a LAB build. The main unknown is whether the tested Android handheld's Shizuku shell identity is permitted to open and `EVIOCGRAB` the physical `/dev/input/eventX` controller node.

Possible results:

- `GRABBED` -> excellent; test PASSTHROUGH next.
- `GRAB FAILED -13` -> permission denied by the device kernel/SELinux; we need a different privileged route.
- controller grabs but an axis is wrong -> change the physical axis profile between AUTO / Xbox-Linux / Android.

Do not publish this as universal compatibility until hardware testing confirms GRAB + PASSTHROUGH.
